package parkin;

public class Park {
	private int parkid;
	private String startpark;
	private int sumpark;
	private int cardid;
	private int stationid;
	private int lastNumber = 1000;
	public int getparkid() {
		return parkid;
	}
	public void setOutid(int parkid) {
		this.parkid = parkid;
	}
	public int getSumpark() {
		return sumpark;
	}
	public void setSumpark(int sumpark) {
		this.sumpark = sumpark;
	}	
	public int getCardid() {
		return cardid;
	}
	public void setCardid(int cardid) {
		this.cardid = cardid;
	}
	public int getStationid() {
		return stationid;
	}
	public void setStationid(int stationid) {
		this.stationid = stationid;
	}
	public String getStartpark() {
		return startpark;
	}
	public void setStartpark(String startpark) {
		this.startpark = startpark;
	}
}
