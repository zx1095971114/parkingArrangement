package parkin;
import parkin.*;
import java.sql.*;
import java.util.*;
import parkin.Preparing;
public class Parkingin extends DataBaseImplement {
	
	String nextOrder = null;
	public void order() {
		Scanner input = new Scanner(System.in);
		System.out.println("请输入:");
		String order = input.nextLine();
		while(order != null){
			nextOrder = order;
			Preparing.preparing(nextOrder);
			
		}
		

}
/*
 * 车辆入场
 * 
 */
public  String parkin(int cardid,int stationid,String stationtype,String startpark){
	String outputOrder = "欢迎光临";
	

		
	while (nextOrder!= null) {
	try{
		String sql="insert park(cardid,stationid,stationtype,startpark) values("+cardid+","+stationid+",'"+stationtype+"','"+startpark+"')";//将入场车辆信息插入到数据库中
		String seResults = null;
		sql.add_update_delete();
		
		
	}catch(Exception e){
		e.printStackTrace();
		
	}
	if(parkid == lastNumber)
		outputOrder = "车位已满。";
	return outputOrder;
}
	}

	/*
	 * 车辆入场
	 * 
	 */
	
}